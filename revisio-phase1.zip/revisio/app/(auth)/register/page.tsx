"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { UserRole } from "@/types/database.types";

export default function RegisterPage() {
  const router = useRouter();
  const supabase = createClient();

  const [role, setRole] = useState<UserRole>("child");
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (signUpError || !data.user) {
      setError("Impossible de créer le compte. Vérifie l'email et le mot de passe (8 caractères minimum).");
      setLoading(false);
      return;
    }

    // Création du profil applicatif. Si la confirmation email est activée
    // côté Supabase, data.session sera null ici : le profil sera créé au
    // premier login après confirmation (à brancher en Phase 1 finale via
    // un Route Handler /auth/callback dédié).
    if (data.session) {
      const { error: profileError } = await supabase.from("users").insert({
        id: data.user.id,
        email,
        role,
        display_name: displayName,
      });

      if (profileError) {
        setError("Compte créé mais le profil n'a pas pu être initialisé.");
        setLoading(false);
        return;
      }

      // TODO Phase 1 (finalisation) : si role = 'child', proposer de rejoindre
      // la famille d'un parent existant via un code d'invitation plutôt que
      // de toujours créer une nouvelle famille. Pour l'instant, chaque
      // inscription crée sa propre famille — le rattachement parent/enfant
      // reste à concevoir avant l'ouverture aux utilisateurs réels.
      const { data: family, error: familyError } = await supabase
        .from("families")
        .insert({ name: `Famille de ${displayName}` })
        .select()
        .single();

      if (familyError || !family) {
        setError("Compte créé mais la famille n'a pas pu être initialisée.");
        setLoading(false);
        return;
      }

      await supabase
        .from("family_members")
        .insert({ family_id: family.id, user_id: data.user.id });

      // Le déclencheur SQL on_child_created provisionne automatiquement
      // le squelette officiel si role = 'child'.
      router.push("/dashboard");
      router.refresh();
    } else {
      setCheckEmail(true);
    }

    setLoading(false);
  }

  if (checkEmail) {
    return (
      <Card>
        <h1 className="font-display font-bold text-lg mb-2">Vérifie ta boîte mail</h1>
        <p className="text-sm text-ink-muted">
          Un email de confirmation a été envoyé à <strong>{email}</strong>. Clique sur le
          lien pour activer ton compte.
        </p>
      </Card>
    );
  }

  return (
    <Card>
      <h1 className="font-display font-bold text-lg mb-1">Créer un compte</h1>
      <p className="text-sm text-ink-muted mb-6">Pour qui est ce compte ?</p>

      <div className="flex gap-2 mb-5">
        <button
          type="button"
          onClick={() => setRole("child")}
          className={cn(
            "flex-1 rounded-card border px-4 py-3 text-sm font-medium transition-colors",
            role === "child"
              ? "border-primary bg-primary/5 text-primary"
              : "border-border text-ink-muted"
          )}
        >
          Élève
        </button>
        <button
          type="button"
          onClick={() => setRole("parent")}
          className={cn(
            "flex-1 rounded-card border px-4 py-3 text-sm font-medium transition-colors",
            role === "parent"
              ? "border-primary bg-primary/5 text-primary"
              : "border-border text-ink-muted"
          )}
        >
          Parent
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <Input
          placeholder="Prénom"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          required
        />
        <Input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <Input
          type="password"
          placeholder="Mot de passe (8 caractères min.)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          minLength={8}
          required
        />

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={loading} className="w-full">
          {loading ? "Création..." : "Créer mon compte"}
        </Button>
      </form>

      <p className="text-sm text-ink-muted text-center mt-6">
        Déjà un compte ?{" "}
        <a href="/login" className="text-primary font-medium">
          Se connecter
        </a>
      </p>
    </Card>
  );
}
