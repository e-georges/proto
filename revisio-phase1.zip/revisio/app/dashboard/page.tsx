import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

// Aiguillage : un enfant atterrit sur son dashboard, un parent sur le sien.
export default async function DashboardRouter() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("users")
    .select("role")
    .eq("id", user.id)
    .single();

  redirect(profile?.role === "parent" ? "/parent-dashboard" : "/child-dashboard");
}
