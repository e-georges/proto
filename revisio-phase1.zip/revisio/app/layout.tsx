import type { Metadata, Viewport } from "next";
import { Sora, Lexend } from "next/font/google";
import "./globals.css";

// Sora : typo display géométrique et confiante — porte les chiffres
// ("12 minutes", "82 %") qui structurent le dashboard.
const sora = Sora({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["600", "700", "800"],
});

// Lexend : conçue spécifiquement pour améliorer la vitesse de lecture —
// un choix pertinent pour une application dont l'usage central est la lecture
// de fiches de révision par une adolescente, plutôt qu'une police neutre par défaut.
const lexend = Lexend({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "Révisio",
  description: "Le coach de révision qui suit le programme tout au long de l'année.",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#2563EB",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className={`${sora.variable} ${lexend.variable} font-body antialiased`}>
        {children}
      </body>
    </html>
  );
}
