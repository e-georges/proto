import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Card } from "@/components/ui/card";

export default async function ParentDashboard() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  // Récupère les enfants partageant la même famille que ce parent.
  const { data: members } = await supabase
    .from("family_members")
    .select("family_id")
    .eq("user_id", user.id);

  const familyIds = members?.map((m) => m.family_id) ?? [];

  const { data: children } = familyIds.length
    ? await supabase
        .from("family_members")
        .select("users(id, display_name)")
        .in("family_id", familyIds)
    : { data: [] };

  return (
    <main className="min-h-screen px-5 py-8 max-w-2xl mx-auto">
      <h1 className="font-display font-extrabold text-2xl mb-6">Suivi famille</h1>

      {!children?.length ? (
        <Card className="text-center py-10">
          <p className="font-display font-semibold text-ink mb-1">Aucun enfant rattaché</p>
          <p className="text-sm text-ink-muted">
            Le rattachement parent/enfant sera disponible dans une prochaine étape.
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {children.map((c: any, i: number) => (
            <Card key={i}>
              <p className="font-display font-semibold">{c.users?.display_name}</p>
              <p className="text-sm text-ink-muted mt-1">
                Temps de travail et régularité — disponibles en Phase 3/4
              </p>
            </Card>
          ))}
        </div>
      )}
    </main>
  );
}
