import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Card, TabCard } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const TIER_LABEL: Record<string, string> = {
  empty: "À ajouter",
  generic: "Aperçu général",
  authoritative: "Ton cours",
};

export default async function ChildDashboard() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("users")
    .select("display_name")
    .eq("id", user.id)
    .single();

  const { data: subjects } = await supabase
    .from("subjects")
    .select("id, name, color, chapters(id, title, content_tier)")
    .eq("child_id", user.id)
    .order("name");

  const totalChapters =
    subjects?.reduce((acc, s) => acc + (s.chapters?.length ?? 0), 0) ?? 0;
  const authoritativeChapters =
    subjects?.reduce(
      (acc, s) =>
        acc + (s.chapters?.filter((c) => c.content_tier === "authoritative").length ?? 0),
      0
    ) ?? 0;

  return (
    <main className="min-h-screen px-5 py-8 max-w-2xl mx-auto">
      <p className="text-ink-muted text-sm">Bonjour {profile?.display_name ?? ""} 👋</p>
      <h1 className="font-display font-extrabold text-2xl mt-1 mb-6">Aujourd&apos;hui</h1>

      {authoritativeChapters === 0 ? (
        // État vide traité comme une invitation à agir, pas un manque.
        <Card className="mb-8 text-center py-10">
          <p className="font-display font-semibold text-ink mb-1">
            Aucun cours ajouté pour l&apos;instant
          </p>
          <p className="text-sm text-ink-muted mb-5">
            Le programme de seconde est déjà là. Ajoute ton premier cours pour générer
            tes fiches et tes premiers quiz.
          </p>
          <Button>Ajouter un cours</Button>
        </Card>
      ) : (
        <Card className="mb-8">
          <p className="font-display font-bold text-3xl text-primary">
            {authoritativeChapters}
          </p>
          <p className="text-sm text-ink-muted">cours prêts à réviser sur {totalChapters}</p>
        </Card>
      )}

      <h2 className="font-display font-semibold text-base mb-3">Tes matières</h2>
      <div className="grid grid-cols-2 gap-4">
        {subjects?.map((subject) => (
          <TabCard key={subject.id} color={subject.color}>
            <p className="font-display font-semibold text-sm">{subject.name}</p>
            <p className="text-xs text-ink-muted mt-1">
              {subject.chapters?.length ?? 0} chapitres
            </p>
          </TabCard>
        ))}
      </div>
    </main>
  );
}
